package com.angular.crud.model;

import java.time.LocalDate;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="product_info")
public class Products {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name="product_name")
	private String product_name;
	
	@Column(name="product_type")
	private String product_type;
	
	@Column(name="product_color")
	private String product_color;
	
	@Column(name="product_price")
	private float product_price;
	
	
	@Column(name="launch_date")
	private LocalDate launch_date;
	
	@Column(name="update_date")
	private LocalDate update_date;
	
	
	

	public Products() {
		// TODO Auto-generated constructor stub
	}

	public Products(String product_name, String product_type, String product_color, float product_price,
			LocalDate launch_date, LocalDate update_date) {
		super();
		this.product_name = product_name;
		this.product_type = product_type;
		this.product_color = product_color;
		this.product_price = product_price;
		this.launch_date = launch_date;
		this.update_date = update_date;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public String getProduct_type() {
		return product_type;
	}

	public void setProduct_type(String product_type) {
		this.product_type = product_type;
	}

	public String getProduct_color() {
		return product_color;
	}

	public void setProduct_color(String product_color) {
		this.product_color = product_color;
	}

	public float getProduct_price() {
		return product_price;
	}

	public void setProduct_price(float f) {
		this.product_price = f;
	}

	public LocalDate getLaunch_date() {
		return launch_date;
	}

	public void setLaunch_date(LocalDate launch_date) {
		this.launch_date = launch_date;
	}

	public LocalDate getUpdate_date() {
		return update_date;
	}

	public void setUpdate_date(LocalDate update_date) {
		this.update_date = update_date;
	}

	@Override
	public String toString() {
		return "Products [id=" + id + ", product_name=" + product_name + ", product_type=" + product_type
				+ ", product_color=" + product_color + ", product_price=" + product_price + ", launch_date="
				+ launch_date + ", update_date=" + update_date + "]";
	}

	
	
	
	
}	
	


