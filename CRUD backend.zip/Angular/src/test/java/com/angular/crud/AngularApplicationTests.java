package com.angular.crud;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AngularApplicationTests {

	@org.junit.Test
	void contextLoads() {
	}

}
