import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProductService } from '../product.service';
import { products } from '../products';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {
  id!:number;
  product: products = new products()
  route: any;
  constructor(private productService: ProductService, private router: Router) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];
    this.productService.getProductById(this.id).subscribe(data =>{
        this.product = data;
    })
  }

  saveProduct(){
    this.productService.addProduct(this.product).subscribe(body =>{
      this.goToList();
      console.log(body);
    })
  }

  goToList(){
    this.router.navigate(["/products"]);
  }
  
  onSubmit(){
    console.log(this.product);
    this.saveProduct();
  }

}
