import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { products } from './products';

//@CrossOrigin(origin = "http://localhost:4200")

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private baseURL = "http://localhost:8080/api/v1/products";

  constructor(private httpClient: HttpClient) { }

  getProductList(): Observable<products[]>{

    return this.httpClient.get<products[]>(`${this.baseURL}`);
  }
  
  addProduct(product: products): Observable<object>{
    return this.httpClient.post(`${this.baseURL}`, product);
  }

  getProductById(id: number): Observable<products>{
    return this.httpClient.get<products>(`${this.baseURL}/${id}`);
  }

  updateProduct(id: number, product: products): Observable<object>{
    return this.httpClient.put(`${this.baseURL}/${id}`, product);
  }
  
  deleteProduct(id: number): Observable<object>{
    return this.httpClient.delete(`${this.baseURL}/${id}`);
  }
}
