import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProductService } from '../product.service';
import { products } from "../products"


@Component({
  
  selector: 'app-products-list',
  templateUrl: './products-list.component.html',
  styleUrls: ['./products-list.component.css']
})
export class ProductsListComponent implements OnInit {

  Product!: products[];
  
  constructor(private productService: ProductService, 
    private router: Router) { }

  ngOnInit(): void {
    this.getProduct();
  }
    private getProduct(){
      this.productService.getProductList().subscribe(data => {
        this.Product = data;
      });
    }

    updateProduct(id: number){
      this.router.navigate(['update-product', id]);
    }

    deleteProduct(id: number){
      this.productService.deleteProduct(id).subscribe(data =>{
        console.log(data);
        this.getProduct();
      })
    }

    productDetails(id: number){
      this.router.navigate(['product-details', id]);
    }
}


