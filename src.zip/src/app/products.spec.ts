import { products } from './products';

describe('Products', () => {
  it('should create an instance', () => {
    expect(new products()).toBeTruthy();
  });
});
