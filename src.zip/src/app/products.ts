export class products {
    'id': number;
    'product_name': String;
    'product_type': String;
    'product_color': String;
    'product_price': Number;
    'launch_date': Date;
    'update_date': Date;

}
