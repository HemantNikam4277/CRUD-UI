import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from '../product.service';
import { products } from '../products';

@Component({
  selector: 'app-update-product',
  templateUrl: './update-product.component.html',
  styleUrls: ['./update-product.component.css']
})
export class UpdateProductComponent implements OnInit {

  id!: number;
  product: products = new products()
  constructor(private productService: ProductService, private router: Router, 
    private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];
    this.productService.getProductById(this.id).subscribe(data =>{
        this.product = data;
    })
  }

  saveProduct(){
    this.productService.addProduct(this.product).subscribe(body =>{
      
      console.log(body);
    })
  }

  goToList(){
    this.router.navigate(["/products"]);
  }
  
  onSubmit(){
    this.productService.updateProduct(this.id, this.product).subscribe(data =>{
       this.goToList();
    })
      
    
  }

}
